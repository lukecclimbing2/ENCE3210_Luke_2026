#include <Arduino.h>

const int BTN_PIN = 2;
const int RED_PIN = 9;
const int GREEN_PIN = 10;
const int BLUE_PIN = 11;

volatile bool running = false;
volatile unsigned long lastIsrUs = 0;
const unsigned long DEBOUNCE_US = 30000;

const unsigned long STEP_MS = 300;

int stepIndex = 0;
unsigned long lastStepMs = 0;

void setLEDs(bool r, bool g, bool b) {
  digitalWrite(RED_PIN, r ? HIGH : LOW);
  digitalWrite(GREEN_PIN, g ? HIGH : LOW);
  digitalWrite(BLUE_PIN, b ? HIGH : LOW);
}

void allOff() { setLEDs(false, false, false); }

void doStep(int idx) {
  switch (idx) {
    case 0: setLEDs(true,  false, false); break; // R
    case 1: setLEDs(true,  true,  false); break; // RG
    case 2: setLEDs(true,  true,  true ); break; // RGB
    case 3: setLEDs(false, true,  true ); break; // GB
    case 4: setLEDs(false, false, true ); break; // B
    case 5: setLEDs(true,  false, true ); break; // RB
  }
}

void ISR_toggle() {
  unsigned long now = micros();
  if (now - lastIsrUs >= DEBOUNCE_US) {
    running = !running;
    lastIsrUs = now;
  }
}

void setup() {
  pinMode(BTN_PIN, INPUT_PULLUP);

  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  allOff();

  attachInterrupt(digitalPinToInterrupt(BTN_PIN), ISR_toggle, FALLING);
}

void loop() {
  bool run;
  noInterrupts();
  run = running;
  interrupts();

  if (!run) {
    allOff();
    stepIndex = 0;
    lastStepMs = millis();
    return;
  }

  unsigned long now = millis();
  if (now - lastStepMs >= STEP_MS) {
    lastStepMs = now;
    doStep(stepIndex);
    stepIndex = (stepIndex + 1) % 6;
  }
}
