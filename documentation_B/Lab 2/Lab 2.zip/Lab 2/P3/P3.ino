#include <Arduino.h>

const int BTN_SELECT = 2;  
const int BTN_RUN    = 3;  

const int RED_PIN   = 9;
const int GREEN_PIN = 10;
const int BLUE_PIN  = 11;

int A[10] = { 1,2,3,4,5,6,7,8,9,10 };
int B[10] = { 10,9,8,7,6,5,4,3,2,1 };
int C[10];

volatile int opMode = 0;          // 1 +, 2 -, 3 *
volatile bool runRequested = false;

volatile unsigned long lastIsrUsSel = 0;
volatile unsigned long lastIsrUsRun = 0;
const unsigned long DEBOUNCE_US = 30000;

void setLEDs(bool r, bool g, bool b) {
  digitalWrite(RED_PIN, r ? HIGH : LOW);
  digitalWrite(GREEN_PIN, g ? HIGH : LOW);
  digitalWrite(BLUE_PIN, b ? HIGH : LOW);
}
void allOff() { setLEDs(false,false,false); }
void allOn()  { setLEDs(true,true,true); }

void showOpLED(int mode) {
  if (mode == 1)      setLEDs(true,  false, false);
  else if (mode == 2) setLEDs(false, true,  false);
  else if (mode == 3) setLEDs(false, false, true );
  else                allOff();
}

void ISR_select() {
  unsigned long now = micros();
  if (now - lastIsrUsSel >= DEBOUNCE_US) {
    opMode++;
    if (opMode > 3) opMode = 1;
    lastIsrUsSel = now;
  }
}

void ISR_run() {
  unsigned long now = micros();
  if (now - lastIsrUsRun >= DEBOUNCE_US) {
    runRequested = true;
    lastIsrUsRun = now;
  }
}

void setup() {
  Serial.begin(9600);
  while (!Serial) {}

  pinMode(BTN_SELECT, INPUT_PULLUP);
  pinMode(BTN_RUN, INPUT_PULLUP);

  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  allOff();

  attachInterrupt(digitalPinToInterrupt(BTN_SELECT), ISR_select, FALLING);
  attachInterrupt(digitalPinToInterrupt(BTN_RUN), ISR_run, FALLING);

  Serial.println("Lab2 P3: SELECT cycles op (R/G/B). RUN computes C[i].");
}

void loop() {
  int mode;
  bool run;

  noInterrupts();
  mode = opMode;
  run  = runRequested;
  if (runRequested) runRequested = false;
  interrupts();

  showOpLED(mode);

  if (run) {
    allOff();
    for (int i = 0; i < 10; i++) {
      if (mode == 1)      C[i] = A[i] + B[i];
      else if (mode == 2) C[i] = A[i] - B[i];
      else if (mode == 3) C[i] = A[i] * B[i];
      else                C[i] = 0;
    }

    Serial.print("Computed with opMode=");
    Serial.println(mode);
    for (int i = 0; i < 10; i++) {
      Serial.print("C["); Serial.print(i); Serial.print("]=");
      Serial.println(C[i]);
    }

    allOn(); 
    delay(200);
  }
}
