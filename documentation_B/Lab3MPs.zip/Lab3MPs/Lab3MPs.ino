#include <avr/io.h>
#include <avr/interrupt.h>

const int GREEN_LED = 13;   
const int RED_LED   = 12;   
const int BUTTON_PIN = 2;   

volatile unsigned long task1Counter = 0;

volatile unsigned int timer2TickCount = 0;

void setupGPIO();
void setupTimer1();
void setupTimer2();

void setup() {
  Serial.begin(9600);

  setupGPIO();
  setupTimer1();
  setupTimer2();

  sei();  
}

void loop() {
  static unsigned long lastPrintCount = 0;
  unsigned long currentCount;


  cli();
  currentCount = task1Counter;
  sei();

  
  if ((currentCount - lastPrintCount) >= 3) {
    Serial.println("Hello from the main task!");
    lastPrintCount = currentCount;
  }
}


void setupGPIO() {
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  digitalWrite(GREEN_LED, LOW);
  digitalWrite(RED_LED, LOW);
}


void setupTimer1() {
  cli();

  TCCR1A = 0;
  TCCR1B = 0;
  TCNT1  = 0;

  OCR1A = 15624;                 
  TCCR1B |= (1 << WGM12);        
  TCCR1B |= (1 << CS12) | (1 << CS10); 
  TIMSK1 |= (1 << OCIE1A);       

  sei();
}


void setupTimer2() {
  cli();

  TCCR2A = 0;
  TCCR2B = 0;
  TCNT2  = 0;

  OCR2A = 124;                   
  TCCR2A |= (1 << WGM21);        
  TCCR2B |= (1 << CS22) | (1 << CS20); 
  TIMSK2 |= (1 << OCIE2A);       

  sei();
}


ISR(TIMER1_COMPA_vect) {
  digitalWrite(GREEN_LED, !digitalRead(GREEN_LED)); 
  task1Counter++;                                   
}


ISR(TIMER2_COMPA_vect) {
  timer2TickCount++;

  if (timer2TickCount >= 100) {
    timer2TickCount = 0;

    if (digitalRead(BUTTON_PIN) == LOW) {
      digitalWrite(RED_LED, HIGH);
    } else {
      digitalWrite(RED_LED, LOW);
    }
  }
}